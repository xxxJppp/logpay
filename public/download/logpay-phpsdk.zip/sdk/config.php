<?php
$config = array (
         //商户ID(uid) 必填
		'uid' => "",

         //商户密钥(token) 必填
		'token' => "",

		 //商户异步回调地址(notify_url) 必填
		'notify_url' => "",

		 //商户同步回调地址(return_url) 必填
		'return_url' => ""
);
?>