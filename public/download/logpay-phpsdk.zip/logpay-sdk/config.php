<?php
$config = array (
         //商户ID(uid)
		'uid' => "",

         //商户密钥(token)
		'token' => "",

		 //商户异步回调地址(notify_url)
		'notify_url' => "",

		 //商户异步回调地址(return_url)
		'return_url' => ""
);
?>